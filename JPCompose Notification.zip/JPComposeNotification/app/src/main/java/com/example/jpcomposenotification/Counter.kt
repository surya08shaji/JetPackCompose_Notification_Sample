package com.example.jpcomposenotification

object Counter {
    var value = 0
}